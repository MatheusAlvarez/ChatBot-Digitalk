// const header = document.querySelector("header");
// const mobile = document.querySelector(".mobile");
// mobile.addEventListener("click", function onMobileClick() {
//   header.classList.toggle("open");
// });

const header = document.querySelector("header");
      const mobile = document.querySelector(".mobile");
      mobile.addEventListener("click", function onMobileClick() {
        header.classList.toggle("open");
      });
const drop = document.querySelectorAll('.descer')
const head = document.querySelectorAll('.head-text')
let arr = []
let newArray = []
for(let k = 0; k < head.length; k++){
    arr.push(k)
    newArray.push(k)
}
for (let i = 0; i < head.length; i++) {
    head[i].addEventListener('click', function descerConteudo(){
        drop[i].classList.toggle('hide')
        console.log(drop[i].textContent)
        let index = arr.indexOf(i)
        arr.splice(index, 1)
        console.log(newArray)
        for (let j = 0; j < arr.length; j++){
            drop[arr[j]].classList.add('hide')
        }
        for(let g = 0; g < newArray.length; g++){
            arr[g] = newArray[g]
        }
    })
}


