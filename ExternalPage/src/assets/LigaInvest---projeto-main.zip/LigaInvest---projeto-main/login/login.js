const itens = document.querySelectorAll(".nav-itens");
for(let i = 0; i < itens.length; i++){
    itens[i].addEventListener("click", function showItens(){
        itens[i].classList.toggle("bar")
    })
}